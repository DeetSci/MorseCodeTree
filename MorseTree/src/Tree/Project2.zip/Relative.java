package Tree;

//enumeration for binary tree
public enum Relative
{
	 LEFT, PARENT, RIGHT, ROOT
}
